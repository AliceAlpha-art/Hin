# Step 2

A Pen created on CodePen.

Original URL: [https://codepen.io/Nicholas-Ng-F5A-Nicholas-Ng-23/pen/JodmYGM](https://codepen.io/Nicholas-Ng-F5A-Nicholas-Ng-23/pen/JodmYGM).

